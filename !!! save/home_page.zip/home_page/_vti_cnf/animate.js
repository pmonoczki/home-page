vti_encoding:SR|utf8-nl
vti_author:SR|ELINOR\\Monoczki Pál
vti_modifiedby:SR|ELINOR\\Monoczki Pál
vti_timelastmodified:TR|06 Mar 2005 10:24:54 -0000
vti_timecreated:TR|06 Mar 2005 10:24:54 -0000
vti_lineageid:SR|{55E3CFF4-014B-4183-ADC9-8AC21FFDD340}
vti_cacheddtm:TX|06 Mar 2005 10:24:56 -0000
vti_filesize:IR|16040
vti_extenderversion:SR|5.0.2.2623
vti_backlinkinfo:VX|index.htm
